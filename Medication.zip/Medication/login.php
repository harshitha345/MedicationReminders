<?php

// Include the database configuration
include('dataconfig.php');  // Ensure this file contains the database connection

// Check if the form is submitted via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the name and password from the POST request
    $name = $_POST['name'];
    $password = $_POST['password'];

    // Create a query to check the provided credentials
    $sql = "SELECT * FROM users WHERE name = ?";  // Assuming 'users' is the table containing user data

    // Prepare and bind the query to avoid SQL injection
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("s", $name);  // 's' stands for string type
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the user exists
        if ($result->num_rows > 0) {
            // Fetch user data
            $user = $result->fetch_assoc();

            // Verify the password (assuming passwords are stored as plaintext; ideally, they should be hashed)
            if ($password == $user['password']) {
                echo "Login successful for $name!";
            } else {
                echo "Invalid name or password.";
            }
        } else {
            echo "Invalid name or password.";
        }

        $stmt->close();  // Close the statement
    } else {
        echo "Database query failed.";
    }
} else {
    // If POST data is not received, show a message
    echo "Please submit the login form.";
}

// Close the database connection
$conn->close();
?>
