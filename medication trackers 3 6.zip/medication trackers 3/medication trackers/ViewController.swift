//
//  ViewController.swift
//  medication trackers
//
//  Created by SAIL on 24/12/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

