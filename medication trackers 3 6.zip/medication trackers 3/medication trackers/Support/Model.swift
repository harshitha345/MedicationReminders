//
//  Model.swift
//  medication trackers
//
//  Created by SAIL on 30/01/25.
//


import Foundation

struct Login: Codable{
    let status: Bool
    let message:String
}



import Foundation

// MARK: - Welcome
struct Medicine: Codable {
    let status: Bool
    let message: String
    let data: [MedicineDatum]
}

// MARK: - Datum
struct MedicineDatum: Codable {
    let medName: String 
    let medType: String
    let medStrength: String
    let medDaily: String
    let medTimes: String
    let intake: String
    let time: String
    let id: Int
}


struct NotificationData {
    let time: String
    let title: String
    let body: String
    let identifier: String
}
