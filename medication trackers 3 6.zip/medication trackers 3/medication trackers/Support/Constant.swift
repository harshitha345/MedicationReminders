

import Foundation

class ServiceAPI: Codable {
    
         static var baseApi = "http://localhost/MedicationReminder/"
         static var userLogin = baseApi+"login.php"
         static var signup = baseApi+"register.php"
         static var addmedicines = baseApi + "addMedicine.php"
         static var listOfMedicine = baseApi + "listOfMedicine.php"
         static var updateMedicine = baseApi + "updateMedicine.php"
         static var displayMedicine = baseApi + "displayMedicine.php"
         static var deleteMed = baseApi + "deletemedicine.php"
         static var progress  = baseApi + "progress.php"
       

         
}



