//
//  Signup.swift
//  medication trackers
//
//  Created by SAIL on 06/02/25.
//

import Foundation
struct Signup: Codable {
    let status: Bool
    let message:String
}


