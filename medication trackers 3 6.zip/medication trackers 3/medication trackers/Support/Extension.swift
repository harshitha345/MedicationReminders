
import UIKit

import UserNotifications

extension UIViewController {
    
    func loadImage(url: String, imageView: UIImageView?) {
        let baseURL = ServiceAPI.baseApi
        guard let imageUrl = URL(string: baseURL + url) else {
            return
        }
        let task = URLSession.shared.dataTask(with: imageUrl) { (data, response, error) in
          guard error == nil, let imageData = data else {
                print("Error downloading image: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            DispatchQueue.main.async {
                if let image = UIImage(data: imageData) {
                    // Set the loaded image to the UIImageView
                    imageView?.image = image
                }
            }
        }
        // Start the URL session task
        task.resume()
    }
    
    
    
//    func scheduleNotifications(notificationData: [NotificationData]) {
//       let dateFormatter = DateFormatter()
//       dateFormatter.dateFormat = "hh:mm a"
//
//       for data in notificationData {
//           guard let fireDate = dateFormatter.date(from: data.time) else {
//               print("Invalid time format for \(data.identifier)")
//               continue
//           }
//
//           let calendar = Calendar.current
//           let dateComponents = calendar.dateComponents([.hour, .minute], from: fireDate)
//
//           let content = UNMutableNotificationContent()
//           content.title = data.title
//           content.body = data.body
//         //  content.sound = UNNotificationSound.default
//
//           content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "Kindly%20take%20your%20Med.mp3"))
//
//           let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
//
//           let request = UNNotificationRequest(identifier: data.identifier, content: content, trigger: trigger)
//
//           UNUserNotificationCenter.current().add(request) { (error) in
//               if let error = error {
//                   print("Error scheduling notification for \(data.identifier): \(error.localizedDescription)")
//               } else {
//                   print("Notification scheduled successfully for \(data.identifier)")
//               }
//
//           }
//
//
//       }
//
//   }
    
    
    func scheduleNotifications(notificationData: [NotificationData]) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy hh:mm a"  // Match the exact input format
        dateFormatter.timeZone = TimeZone.current

        let calendar = Calendar.current

        for data in notificationData {
            // Convert the full date-time string into a Date object
            guard let fireDate = dateFormatter.date(from: data.time) else {
                print("Invalid time format for \(data.time)")
                continue
            }

            let dateComponents = calendar.dateComponents([.year, .month, .day, .hour, .minute], from: fireDate)

            let content = UNMutableNotificationContent()
            content.title = data.title
            content.body = data.body
            content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "Kindly%20take%20your%20Med.mp3"))

            let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
            let request = UNNotificationRequest(identifier: data.identifier, content: content, trigger: trigger)

            UNUserNotificationCenter.current().add(request) { error in
                if let error = error {
                    print("Error scheduling notification for \(data.identifier): \(error.localizedDescription)")
                } else {
                    print("Notification scheduled successfully for \(data.identifier) at \(data.time)")
                }
            }
        }
    }



    
 
    
   
    
//        class NotificationManager {
//        func scheduleNotification(at time: String, title: String, body: String, identifier: String) {
//            DispatchQueue.main.async {
//
//
//           let dateFormatter = DateFormatter()
//           dateFormatter.dateFormat = "hh:mm a"
//
//           guard let fireDate = dateFormatter.date(from: time) else {
//               print("Invalid time format")
//               return
//           }
//
//           let calendar = Calendar.current
//           let dateComponents = calendar.dateComponents([.hour, .minute], from: fireDate)
//
//           let content = UNMutableNotificationContent()
//           content.title = title
//           content.body = body
//
//           // Set the sound for the notification
//           content.sound = UNNotificationSound.default
//
//           let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
//
//           let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
//
//           UNUserNotificationCenter.current().add(request) { (error) in
//               if let error = error {
//                   print("Error scheduling notification: \(error.localizedDescription)")
//               } else {
//                   print("Notification scheduled successfully")
//               }
//           }
//        }
//
//    }
    
}
//     func scheduleNotifications(notificationData: [NotificationData]) {
//        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = "hh:mm a"
//
//        for data in notificationData {
//            guard let fireDate = dateFormatter.date(from: data.time) else {
//                print("Invalid time format for \(data.identifier)")
//                continue
//            }
//
//            let calendar = Calendar.current
//            let dateComponents = calendar.dateComponents([.hour, .minute], from: fireDate)
//
//            let content = UNMutableNotificationContent()
//            content.title = data.title
//            content.body = data.body
//          //  content.sound = UNNotificationSound.default
//
//            content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "Kindly%20take%20your%20Med.mp3"))
//
//            let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
//
//            let request = UNNotificationRequest(identifier: data.identifier, content: content, trigger: trigger)
//
//            UNUserNotificationCenter.current().add(request) { (error) in
//                if let error = error {
//                    print("Error scheduling notification for \(data.identifier): \(error.localizedDescription)")
//                } else {
//                    print("Notification scheduled successfully for \(data.identifier)")
//                }
//
//            }
//
//
//        }
//
//    }
       
        class LoadingIndicator {

            static let shared = LoadingIndicator()

            private let activityIndicator: UIActivityIndicatorView = {
                let indicator = UIActivityIndicatorView(style: .large)
                indicator.color = UIColor.blue
                indicator.hidesWhenStopped = true
                return indicator
            }()

            private init() {}

            func showLoading(on view: UIView) {
                DispatchQueue.main.async {
                    self.activityIndicator.center = view.center
                    view.addSubview(self.activityIndicator)
                    self.activityIndicator.startAnimating()
                }
            }

            func hideLoading() {
                
                let mainQueue = DispatchQueue.main

                // Define a delay in seconds (e.g., 2 seconds)
                let delayInSeconds: Double = 0.3

                // Specify the deadline for the delay
                let deadline = DispatchTime.now() + delayInSeconds

                // Perform a task with a delay
                mainQueue.asyncAfter(deadline: deadline) {
                    // Code to be executed after the delay
                    self.activityIndicator.stopAnimating()
                    self.activityIndicator.removeFromSuperview()
                }
            }
        }


class Datamanager {

    static var shared = Datamanager()
    
    var name = String()
    var type = String()
    var strength = String()
    var daily = String()
    var medtimes = String()
    var intake = String()
    var email = String()
   
}


extension UIViewController {
    
    func sendMessage(title:String,message:String) {

        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: false, completion: nil)
    }
    
}

extension UITextField {

    func setInputViewTimePicker(target: Any, selector: Selector) {
        let screenWidth = UIScreen.main.bounds.width
        let timePicker = UIDatePicker(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 216))
        
        timePicker.datePickerMode = .dateAndTime // Set the picker mode to time

        if #available(iOS 14, *) {
            timePicker.preferredDatePickerStyle = .wheels
            timePicker.sizeToFit()
        }
        self.inputView = timePicker

        let toolBar = UIToolbar(frame: CGRect(x: 0.0, y: 0.0, width: screenWidth, height: 44.0))
        let flexible = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancel = UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: #selector(tapCancel))
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: target, action: selector)

        toolBar.setItems([cancel, flexible, doneButton], animated: false)
        self.inputAccessoryView = toolBar
    }

    @objc func tapCancel() {
        self.resignFirstResponder()
    }
}


