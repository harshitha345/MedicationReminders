//  ScheduleofmedsViewController.swift
//  medication trackers
//  Created by SAIL on 20/01/25.

import UIKit

class ScheduleofmedsViewController: UIViewController {
    
    
    @IBOutlet weak var tableView: UITableView!
    

    var medicine = [MedicineDatum]()
    
    var firstIntakeNot = [NotificationData]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
        
        let cell = UINib(nibName: "MedicineCell", bundle: nil)
        tableView.register(cell, forCellReuseIdentifier: "MedicineCell")
        
        navigationItem.hidesBackButton = false
        

        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getLoginAPI()
    }
    
    
    func getLoginAPI(){
           
        APIHandler().getAPIValues(type: Medicine.self, apiUrl: ServiceAPI.listOfMedicine, method: "GET" ){ result in
                            switch result{
                            case .success(let value):
                                DispatchQueue.main.async { [self] in
                                if value.status == true {
                                   
                                    self.medicine = value.data
                                    
                                    
                                        for ins in value.data {
                                            self.firstIntakeNot.append(NotificationData(time: ins.time, title:"Reminder!", body:"Kindly take your medicine!", identifier: ins.time))
                                        }
                               
    
                                    self.scheduleNotifications(notificationData: self.firstIntakeNot)
                                    self.tableView.reloadData()
                                     }
                                    else {
                                         self.sendMessage(title:"Alert", message: value.message)
                                 }
                                }
                            case .failure(let error):
                                print(error)
                                DispatchQueue.main.async {
                                    self.sendMessage(title:"Alert", message:"Something went wrong!")
                                }
                             }
                        }
                    }
    
    
    
    
}
extension ScheduleofmedsViewController: UITableViewDelegate,UITableViewDataSource {
    
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return medicine.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MedicineCell", for: indexPath) as! MedicineCell
        cell.medName.text = medicine[indexPath.row].medName
        cell.time.text = "\(medicine[indexPath.row].time)"
        cell.intake.text = medicine[indexPath.row].intake
        cell.daily.text = medicine[indexPath.row].medDaily
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 150.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
       let vc = storyboard?.instantiateViewController(withIdentifier: "DisplaymedicineViewController") as!  DisplaymedicineViewController
        vc.list = medicine[indexPath.row]
       self.navigationController?.pushViewController(vc, animated: true)
     
        
    }
    
    }
