//  NooftimesViewController.swift
//  medication trackers
//  Created by SAIL on 20/01/25.
import UIKit

class NooftimesViewController: UIViewController {
    
 
    var selectedMedicationForms: String?
    
    
    @IBOutlet weak var Oncebutton: UIButton!
    
    
    @IBOutlet weak var Twicebutton: UIButton!
    
    
    @IBOutlet weak var Threetimesbutton: UIButton!
    
    
    @IBOutlet weak var Fourtimesbutton: UIButton!
    
    
    @IBOutlet weak var Sixtimesbutton: UIButton!
    
    
    @IBOutlet weak var Onlyasneeded: UIButton!
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        setupButtonStyles()
    }
    
    func setupButtonStyles() {

        let buttons = [Oncebutton, Twicebutton, Threetimesbutton, Fourtimesbutton, Sixtimesbutton, Onlyasneeded]
        buttons.forEach { button in
            button?.layer.cornerRadius = 10
            button?.backgroundColor = .systemGray5
        }
    }
    
    @IBAction func Once(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "Once")
        
    }
    
    @IBAction func Twice(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "Twice")
       
    }
    
    @IBAction func ThreeTimes(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "ThreeTimes")
    }
    
    @IBAction func FourTimes(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "FourTimes")
    }
    
    @IBAction func SixTimes(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "SixTimes")
    }
    
    @IBAction func OnlyAsNeeded(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "OnlyAsNeeded")
    }
    
    
    private func handleButtonSelection(_ sender: UIButton, medicationName: String) {
        resetButtonColors() // Reset previous selections
        sender.backgroundColor = .systemBlue // Highlight selected button
        selectedMedicationForms = medicationName
    }
    
    private func resetButtonColors() {
        let buttons = [Oncebutton, Twicebutton, Threetimesbutton, Fourtimesbutton, Sixtimesbutton, Onlyasneeded]
        buttons.forEach { button in
            button?.backgroundColor = .systemGray5
        }
    }
    
    
    
    @IBAction func nextTap(_ sender: Any) {
        
        guard let selectedForm = selectedMedicationForms
        else {
        // Show alert if no form is selected
        let alert = UIAlertController(title: "No Selection", message: "Please select a the option.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
        return
    }
    Datamanager.shared.intake = selectedMedicationForms ?? ""
    if let vc = storyboard?.instantiateViewController(withIdentifier: "SaveMedicineViewController") as? SaveMedicineViewController {
        vc.selectedMedicationForms = selectedForm
        navigationController?.pushViewController(vc, animated: true)
    }
        
        
        
    }
    
       
        
}
