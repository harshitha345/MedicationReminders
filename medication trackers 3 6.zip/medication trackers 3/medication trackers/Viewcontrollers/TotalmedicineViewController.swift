//  TotalmedicineViewController.swift
//  medication trackers
//  Created by SAIL on 24/02/25.

import UIKit


class TotalmedicineViewController: UIViewController {

    
    @IBOutlet weak var date: UITextField!
    
    let datePicker = UIDatePicker()
    let calendar = Calendar.current
    let currentDate = Date()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        datePicker.datePickerMode = .time
        
        self.date.setInputViewTimePicker(target: self, selector: #selector(tapDone))
    }
 
    @objc func tapDone() {
        if let picker = date.inputView as? UIDatePicker {
            let dateformatter = DateFormatter()
            dateformatter.timeZone = TimeZone.current
            dateformatter.dateFormat = "MM/dd/yyyy hh:mm a" // Date & Time format
            self.date.text = dateformatter.string(from: picker.date)
        }
        self.date.resignFirstResponder()
    }
    
    
    @IBOutlet weak var totalmed: UITextField!
    
    
    
    
    @IBOutlet weak var takenmed: UITextField!
    
    
    
    @IBOutlet weak var missedmed: UITextField!
    
    
    
    @IBOutlet weak var progresspercent: UITextField!
    
        
    @IBAction func OKTap(_ sender: Any) {
    }
}
    


    
