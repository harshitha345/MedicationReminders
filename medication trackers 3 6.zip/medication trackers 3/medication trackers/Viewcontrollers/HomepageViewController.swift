//  HomepageViewController.swift
//  medication trackers
//  Created by SAIL on 20/01/25.
import UIKit


class HomepageViewController: UIViewController,SideMenu {
  
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    
    @IBAction func addmedTap(_ sender: Any) {
    }
    
    
    @IBAction func AddMedTapped(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "MedicinespageViewController") as! MedicinespageViewController
                self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func tapMed(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "ScheduleofmedsViewController") as! ScheduleofmedsViewController
                self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func menuTap(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "SideViewController") as! SideViewController
        vc.modalPresentationStyle = .overCurrentContext
        vc.delefate = self
        navigationController?.present(vc, animated: false, completion: nil)
        
        
    }
    
    
    func tapped(index: Int) {
        switch index {
        case 1:
            
            let vc = storyboard?.instantiateViewController(withIdentifier: "Progress_ViewController") as! Progress_ViewController
            self.navigationController?.pushViewController(vc, animated: true)
        case 2:
            
            let vc = storyboard?.instantiateViewController(withIdentifier: "SettingsViewController") as! SettingsViewController
            self.navigationController?.pushViewController(vc, animated: true)
        case 3:
            
            let vc = storyboard?.instantiateViewController(withIdentifier: "ScheduleofmedsViewController") as! ScheduleofmedsViewController
            self.navigationController?.pushViewController(vc, animated: true)
        default :
            print("123")
        }
    }
    
    
    
}
