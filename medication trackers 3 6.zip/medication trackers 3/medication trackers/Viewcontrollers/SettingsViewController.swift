//  SettingsViewController.swift
//  medication trackers
//  Created by SAIL on 24/02/25.

import UIKit

class SettingsViewController: UIViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func logout(_ sender: Any) {
        showAlert()
    }
    
    
    func showAlert() {
         
                
                DispatchQueue.main.async {
                      let alertController = UIAlertController(title: "Alert", message: "Do you want to logout?", preferredStyle: .alert)
                      let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
  //                        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
                       let adminVC = self.storyboard?.instantiateViewController(identifier: "UserViewController") as! UserViewController
                          if let navigationController = self.navigationController {
                              navigationController.setViewControllers([adminVC], animated: false)
                          }
                      })
                      alertController.addAction(okAction)
                      let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: { _ in
                          // Handle Cancel button tap if needed
                      })
                      alertController.addAction(cancelAction)
                      self.present(alertController, animated: true, completion: nil)
                  }

               
    
        }
    

    @IBAction func AboutTap(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "AboutViewController") as! AboutViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }

  @IBAction func LogoutTap(_ sender: Any) {
      
    }
}


