//
//  SaveMedicineViewController.swift
//  medication trackers
//
//  Created by SAIL on 10/02/25.


import UIKit

class SaveMedicineViewController: UIViewController {
    
    
    @IBOutlet weak var timeLbl: UITextField!
    
    
    var selectedMedicationForms: String?
    
    
    let datePicker = UIDatePicker()
    let calendar = Calendar.current
    let currentDate = Date()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        datePicker.datePickerMode = .time
        
        self.timeLbl.setInputViewTimePicker(target: self, selector: #selector(tapDone))
    }
 
    @objc func tapDone() {
        if let picker = timeLbl.inputView as? UIDatePicker {
            let dateformatter = DateFormatter()
            dateformatter.timeZone = TimeZone.current
            dateformatter.dateFormat = "MM/dd/yyyy hh:mm a" // Date & Time format
            self.timeLbl.text = dateformatter.string(from: picker.date)
        }
        self.timeLbl.resignFirstResponder()
    }
      
    func addMedicine(){
        
        
        let userInfo: [String: String] = [
            "email":Datamanager.shared.email,
            "medName": Datamanager.shared.name,
            "medType": Datamanager.shared.type,
            "medStrength":Datamanager.shared.strength,
            "medDaily": Datamanager.shared.daily,
            "medTimes" : "1",
            "intake" : Datamanager.shared.intake,
            "time" : timeLbl.text ?? "",
        ]
    
        APIHandler().postAPIValues(type: Login.self, apiUrl: ServiceAPI.addmedicines, method: "POST", formData: userInfo) { result in
            switch result{
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    if data.status == true {
                    showAlert()
                    } else {
                        self.sendMessage(title:"Alert", message: data.message)
                    }
                }
            case .failure(let error):
                print(error)
                
                DispatchQueue.main.async {
                    self.sendMessage(title:"Alert", message:"Something went wrong!")
                }
            }
        }
    }
    
    
    func showAlert() {
            // 1. Create the alert controller
            let alert = UIAlertController(
                title: "Alert",
                message: "Medicine added successfully!",
                preferredStyle: .alert
            )
            
            // 2. Add the "OK" action
            let okAction = UIAlertAction(title: "OK", style: .default) { _ in
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "ScheduleofmedsViewController") as! ScheduleofmedsViewController
               self.navigationController?.pushViewController(vc, animated: true)
            }
            alert.addAction(okAction)
            
            // 3. Present the alert
            present(alert, animated: true, completion: nil)
        }
    
    @IBAction func save(_ sender: Any) {
        if timeLbl.text != "" {
            addMedicine()
        }else {
            self.sendMessage(title:"Alert", message: "Should add time!")
        }
        
       
    }
    
}


