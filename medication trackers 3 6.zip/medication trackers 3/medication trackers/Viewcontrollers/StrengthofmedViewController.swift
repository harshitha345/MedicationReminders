//  StrengthofmedViewController.swift
//  medication trackers
//  Created by SAIL on 20/01/25.

import UIKit


class StrengthofmedViewController: UIViewController {
    
    
    var selectedMedicationForm: String?

    
    @IBOutlet weak var mgTap: UIButton!
    
    
    @IBOutlet weak var gTap: UIButton!

    
    @IBOutlet weak var mcgTap: UIButton!
    
    
    @IBOutlet weak var mEqTap: UIButton!
    
    
    @IBOutlet weak var IUTAp: UIButton!
    
    
    @IBOutlet weak var medstrengthfield: UITextField!
    
    
    override func viewDidLoad() {
            super.viewDidLoad()
            if let medicationForm = selectedMedicationForm {
                print("Selected Medication Form: \(medicationForm)")
            }
        }
    

    @IBAction func mgTap(_ sender: Any) {
        medstrengthfield.text = "mg"
    }
    
    
    @IBAction func gTAp(_ sender: Any) {
        medstrengthfield.text = "g"
    }
    
    
    @IBAction func mcgTap(_ sender: Any) {
        medstrengthfield.text = "mcg"
    }
    
    
    @IBAction func mEqTap(_ sender: Any) {
        medstrengthfield.text = "mEq"
    }
    
    
    @IBAction func IUTap(_ sender: Any) {
        medstrengthfield.text = "IU"
    }
    
   
    
    
    @IBAction func nextTap(_ sender: Any) {
    if medstrengthfield.text != "" {
        
        Datamanager.shared.strength = medstrengthfield.text ?? ""
        let vc = storyboard?.instantiateViewController(withIdentifier: "EverydaymedViewController") as! EverydaymedViewController
                    self.navigationController?.pushViewController(vc, animated: true)
    }
    else {
        self.sendMessage(title:"Alert", message: "You should give strength !")
    }
}
    
}
