//  DisplaymedicineViewController.swift
//  medication trackers
//  Created by SAIL on 13/02/25.
import UIKit

class DisplaymedicineViewController: UIViewController {
    
    
    
    
    
    @IBOutlet weak var name: UILabel!
    
    
    
    @IBOutlet weak var type: UILabel!
    
    
    
    @IBOutlet weak var strenght: UILabel!
    
    
    
    @IBOutlet weak var daily: UILabel!
    
    
    
    @IBOutlet weak var time: UILabel!
    
    
    var list:MedicineDatum?
    
   override func viewDidLoad() {
    super.viewDidLoad()
     
       name.text = list?.medName
       type.text = list?.medType
       strenght.text = list?.medStrength
       daily.text = list?.medDaily
       time.text = list?.time
     
     
   }
    
    
    @IBAction func deleteTap(_ sender: Any) {
        showAlert()
        
    }
    
    
    func showAlert() {
            // 1. Create the alert controller
            let alert = UIAlertController(
                title: "Alert",
                message: "Do you want to delete this medicine?",
                preferredStyle: .alert
            )
            
            // 2. Add the "OK" action
            let okAction = UIAlertAction(title: "OK", style: .default) { _ in
                self.getdeleteAPI()
            }
            alert.addAction(okAction)
            
            // 3. Present the alert
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: { _ in
            // Handle Cancel button tap if needed
        })
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
        }
    
    
    func getdeleteAPI(){
        
            let userInfo: [String: String] = [
                "id": "\(list?.id ?? 0)",
               
                ]
        
        
            APIHandler().postAPIValues(type: Login.self, apiUrl: ServiceAPI.deleteMed, method: "POST", formData: userInfo) { result in
                            switch result{
                            case .success(let data):
                                DispatchQueue.main.async { [self] in
                                if data.status == true {
                                    self.navigationController?.popViewController(animated: false)
                                     } else {
                                  self.sendMessage(title:"Alert", message: data.message)
                                 }
                                }
                            case .failure(let error):
                                print(error)
                             
                                DispatchQueue.main.async {
                                    self.sendMessage(title:"Alert", message:"Something went wrong!")
                                }
                             }
                        }
                    }

    
}

