//  FormsofmedViewController.swift
//  medication trackers
//
//  Created by SAIL on 20/01/25.
import UIKit


class FormsofmedViewController: UIViewController {

    
    
    var selectedMedicationForm: String?
    

    @IBOutlet weak var pillButton: UIButton!
    
    
    @IBOutlet weak var solutionButton: UIButton!
    
    
    @IBOutlet weak var injectionButton: UIButton!
    
    
    @IBOutlet weak var powderButton: UIButton!
    
    
    @IBOutlet weak var dropsButton: UIButton!
    
    
    @IBOutlet weak var inhalerButton: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        setupButtonStyles()
        
    }

    
    func setupButtonStyles() {
        let buttons = [pillButton, solutionButton, injectionButton, powderButton, dropsButton, inhalerButton]
        buttons.forEach { button in
            button?.layer.cornerRadius = 10
            button?.backgroundColor = .systemGray5
        }
    }
    // Button tap actions
    @IBAction func PillTap(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "Pill")
    }

    @IBAction func SolutionTap(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "Solution")
    }

    @IBAction func InjectionTap(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "Injection")
    }

    @IBAction func PowderTap(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "Powder")
    }

    @IBAction func DropsTap(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "Drops")
    }

    @IBAction func InhalerTap(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "Inhaler")
    }

    private func handleButtonSelection(_ sender: UIButton, medicationName: String) {
        resetButtonColors() // Reset previous selections
      sender.backgroundColor = .systemBlue // Highlight selected button
        selectedMedicationForm = medicationName
    }

    private func resetButtonColors() {
        let buttons = [pillButton, solutionButton, injectionButton, powderButton, dropsButton, inhalerButton]
        buttons.forEach { button in
            button?.backgroundColor = .systemGray5
        }
    }

    @IBAction func NextTap(_ sender: Any) {
        guard let selectedForm = selectedMedicationForm else {
            // Show alert if no form is selected
            let alert = UIAlertController(title: "No Selection", message: "Please select a medication form.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
            return
        }
        Datamanager.shared.type = selectedMedicationForm ?? ""
        if let vc = storyboard?.instantiateViewController(withIdentifier: "StrengthofmedViewController") as? StrengthofmedViewController {
            vc.selectedMedicationForm = selectedForm
            navigationController?.pushViewController(vc, animated: true)
        }
    }
}
