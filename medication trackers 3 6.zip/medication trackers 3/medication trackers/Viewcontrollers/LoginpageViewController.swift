//  LoginpageViewController.swift
//  medication tracker
//  Created by SAIL on 20/01/25.


import UIKit


class LoginpageViewController: UIViewController {
    
    
    @IBOutlet weak var usernamefield: UITextField!
    
    
    @IBOutlet weak var passwordfield: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    func getLoginAPI(){
        
            let userInfo: [String: String] = [
                "email": usernamefield.text ?? "",
                "password": passwordfield.text ?? ""
                ]
        
        
            APIHandler().postAPIValues(type: Login.self, apiUrl: ServiceAPI.userLogin, method: "POST", formData: userInfo) { result in
                            switch result{
                            case .success(let data):
                                DispatchQueue.main.async { [self] in
                                if data.status == true {
                                    Datamanager.shared.email = usernamefield.text ?? ""
                                     let vc = storyboard?.instantiateViewController(withIdentifier: "HomepageViewController") as! HomepageViewController
                                    self.navigationController?.pushViewController(vc, animated: true)
                                     } else {
                                  self.sendMessage(title:"Alert", message: data.message)
                                 }
                                }
                            case .failure(let error):
                                print(error)
                             
                                DispatchQueue.main.async {
                                    self.sendMessage(title:"Alert", message:"Something went wrong!")
                                }
                             }
                        }
                    }
    
    
    @IBAction func loginTap(_ sender: Any){
        getLoginAPI()
}
    
    
    
    @IBAction func SignupTap(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "UserPageViewController") as! UserPageViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    
}
