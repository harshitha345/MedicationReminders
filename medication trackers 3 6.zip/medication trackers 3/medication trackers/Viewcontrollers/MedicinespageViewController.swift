//  MedicinespageViewController.swift
//  medication trackers
//  Created by SAIL on 20/01/25.

import UIKit

class MedicinespageViewController: UIViewController {

    
    @IBOutlet weak var mednametype: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    @IBAction func nexTap(_ sender: Any) {
        if mednametype.text != "" {
            
            Datamanager.shared.name = mednametype.text ?? ""
            let vc = storyboard?.instantiateViewController(withIdentifier: "FormsofmedViewController") as! FormsofmedViewController
            self.navigationController?.pushViewController(vc, animated: true)
           
        }
        else {
            self.sendMessage(title:"Alert", message: "You should add medicine!")
        }
        
      
    }
    
  
}
