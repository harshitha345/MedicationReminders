import UIKit



class UserPageViewController: UIViewController {
    
    

    @IBOutlet weak var nameField: UITextField!
    
    
    @IBOutlet weak var emailField: UITextField!
    
    
    @IBOutlet weak var passwordField: UITextField!
    
    
    @IBOutlet weak var numberField: UITextField!
    
    
    @IBOutlet weak var genderField: UITextField!
    
    
    @IBOutlet weak var ageField: UITextField!
    
    
    override func viewDidLoad(){
        super.viewDidLoad()
    }

    
    func getRegisterAPI() {
        
        let userInfo: [String: String] = [
            
            "name": nameField.text ?? "",
            "email": emailField.text ?? "",
            "password": passwordField.text ?? "",
            "age": ageField.text ?? "",
            "gender": genderField.text ?? "",
            "number": numberField.text ?? ""
        ]
        
        
        APIHandler().postAPIValues(type: Signup.self, apiUrl: ServiceAPI.signup, method: "POST", formData: userInfo) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    if data.status == true {
                    self.navigationController?.popViewController(animated: false)
                    } else  {
                        self.sendMessage(title: "Alert", message: data.message)
                    }
                }
                
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.sendMessage(title: "Alert", message: "Something went wrong!")
                }
            }
        }
        
    }
    
    
    @IBAction func signupTap(_ sender: Any) {
        getRegisterAPI()
    }

    
    @IBAction func logintap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
}

