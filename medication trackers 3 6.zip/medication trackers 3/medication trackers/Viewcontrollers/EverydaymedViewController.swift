//  EverydaymedViewController.swift
//  medication trackers
//  Created by SAIL on 07/02/25.

import UIKit

class EverydaymedViewController: UIViewController {
    
    
    var selectedMedicationForm: String?
    
    
    @IBOutlet weak var yesbutton: UIButton!
    
    
    @IBOutlet weak var nobutton: UIButton!
    
    
    @IBOutlet weak var onlyasneededbutton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupButtonStyles()
    }

    func setupButtonStyles() {
        let buttons = [yesbutton, nobutton, onlyasneededbutton]
        buttons.forEach { button in
            button?.layer.cornerRadius = 10
            button?.backgroundColor = .systemGray5
        }
    }

    
    
    
    @IBAction func yesbutton(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "Yes")
    }
    
    
    

    @IBAction func nobutton(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "No")
    }
    
    
    @IBAction func onlyasneededbutton(_ sender: UIButton) {
        handleButtonSelection(sender, medicationName: "Onlyasneeded")
    }
    

    private func handleButtonSelection(_ sender: UIButton, medicationName: String) {
        resetButtonColors() // Reset previous selections
        sender.backgroundColor = .systemBlue // Highlight selected button
        selectedMedicationForm = medicationName
    }
    
    
    private func resetButtonColors() {
        let buttons = [yesbutton, nobutton, onlyasneededbutton]
        buttons.forEach { button in
            button?.backgroundColor = .systemGray5
        }
    }

    @IBAction func NextTap(_ sender: Any) {
        
        
        guard selectedMedicationForm != nil
        else {
        // Show alert if no form is selected
        let alert = UIAlertController(title: "No Selection", message: "Please select a the option.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
        return
    }
     
    
        Datamanager.shared.daily = selectedMedicationForm ?? ""
     
        let vc = storyboard?.instantiateViewController(withIdentifier: "NooftimesViewController") as! NooftimesViewController
                        self.navigationController?.pushViewController(vc, animated: true)
        
    }

    
    
    
}
