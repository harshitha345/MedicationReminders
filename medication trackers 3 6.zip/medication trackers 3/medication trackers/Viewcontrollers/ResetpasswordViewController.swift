//
//  ResetpasswordViewController.swift
//  medication trackers
//
//  Created by SAIL on 24/02/25.
//

import UIKit

class ResetpasswordViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    

    @IBAction func OldpassTap(_ sender: Any) {
    }
    
    @IBAction func NewpassTap(_ sender: Any) {
    }
    
    @IBAction func ReenterpassTap(_ sender: Any) {
    }
    
    @IBAction func saveTAp(_ sender: Any) {
    }
}

