    //UserViewController.swift
    //medication trackers
    //Created by SAIL on 26/12/24.
    

    import UIKit

    class UserViewController: UIViewController {
        
        @IBOutlet weak var subView: UIView!
        
        @IBOutlet weak var topLbl: UILabel!
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            subView.clipsToBounds = true
        
            subView.layer.cornerRadius = 50
            
            subView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
            
        }
        @IBAction func Password(_ sender: Any) {
            
        }
        @IBAction func signUpTap(_ sender: Any) {
            
            
            let vc = storyboard?.instantiateViewController(withIdentifier: "UserPageViewController") as! UserPageViewController
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
        @IBAction func loginTap(_ sender: Any) {
            let vc = storyboard?.instantiateViewController(withIdentifier: "LoginpageViewController") as! LoginpageViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
