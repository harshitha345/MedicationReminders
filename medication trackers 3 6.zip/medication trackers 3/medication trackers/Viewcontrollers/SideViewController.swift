//
//  SideViewController.swift
//  medication trackers
//
//  Created by SAIL on 24/02/25.
//

import UIKit

protocol SideMenu {
    func tapped(index:Int)
}


class SideViewController: UIViewController {
    
    
    var delefate:SideMenu?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func progress(_ sender: Any) {
        self.delefate?.tapped(index: 1)
        self.dismiss(animated: false, completion: nil)
    }
    
    
    @IBAction func settingTap(_ sender: Any) {
        self.delefate?.tapped(index: 2)
        self.dismiss(animated: false, completion: nil)
    }
    
    
    
    @IBAction func close(_ sender: Any) {
        
        self.dismiss(animated: false, completion: nil)

    }
    
}
