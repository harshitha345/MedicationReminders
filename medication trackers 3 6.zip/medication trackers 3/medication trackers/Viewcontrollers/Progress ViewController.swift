//
//  Progress ViewController.swift
//  medication trackers
//
//  Created by SAIL on 22/02/25.

import UIKit

class Progress_ViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()

       

    }
    
    @IBAction func doneTap(_ sender: Any) {
        let alert = UIAlertController(
            title: "Alert",
            message: "Done successfully!",
            preferredStyle: .alert
        )
        
        // 2. Add the "OK" action
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ScheduleofmedsViewController") as! ScheduleofmedsViewController
           self.navigationController?.pushViewController(vc, animated: true)
        }
        alert.addAction(okAction)
        
        // 3. Present the alert
        present(alert, animated: true, completion: nil)
    }
    }
