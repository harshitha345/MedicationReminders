//
//  AboutViewController.swift
//  medication trackers
//
//  Created by SAIL on 24/02/25.
//

import UIKit

class AboutViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    


}
