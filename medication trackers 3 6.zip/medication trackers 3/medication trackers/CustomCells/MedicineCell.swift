//
//  MedicineCell.swift
//  medication trackers
//
//  Created by SAIL on 10/02/25.
//

import UIKit

class MedicineCell: UITableViewCell {
    
    
    
    @IBOutlet weak var medName: UILabel!
    
    
    @IBOutlet weak var time: UILabel!
    
    
    
    @IBOutlet weak var daily: UILabel!
    
    
    @IBOutlet weak var intake: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func layoutSubviews() {
      super.layoutSubviews()
      
   let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
   contentView.frame = contentView.frame.inset(by: margin)
        contentView.layer.cornerRadius = 30
 
  }
    
}
